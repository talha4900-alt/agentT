"""agentT SEO Auditor."""
__version__ = "0.1.0"
